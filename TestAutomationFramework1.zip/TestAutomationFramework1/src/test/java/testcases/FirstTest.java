package testcases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import Utilities.*;

import org.apache.log4j.helpers.Loader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTest;

public class FirstTest extends BaseTest {
	@SuppressWarnings("deprecation")
	@BeforeMethod
	public static void login() throws InterruptedException
	 {
	 	driver.findElement(By.xpath(loc.getProperty("Microsoft_Office_Text"))).click();
	     driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(30));
	    Thread.sleep(2000);
	    driver.findElement(By.xpath(loc.getProperty("Email"))).sendKeys("neha.goyal@cubastion.com");
	    Thread.sleep(1000);
	     driver.findElement(By.xpath(loc.getProperty("Submit_Button"))).click();
	     Thread.sleep(1000);
	     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	     driver.findElement(By.xpath(loc.getProperty("Password"))).sendKeys("SelStart@12345");
	     Thread.sleep(1000);
	     driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	     driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(30)); 
	     driver.findElement(By.xpath(loc.getProperty("SignIn"))).click();
	     Thread.sleep(1000);
	     driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(30)); 
	     //driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	     driver.findElement(By.xpath(loc.getProperty("YesButton"))).click();
	     Thread.sleep(1000);
	     driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(30)); 
	  	     	
	   	}

@SuppressWarnings("deprecation")
@Test
public static void FileUpload()throws IOException, InterruptedException, AWTException
{
driver.navigate().refresh();
	
driver.findElement(By.xpath("//p[@class='Tasks']")).click();
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      
Thread.sleep(1000);
	     
//Table Xpath
WebElement table = driver.findElement(By.xpath("//*[@id='custom-tabs-two-tabContent']/div/div[1]/div[2]/div/div/table"));
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//click on + button
WebElement elementInsideTable = table.findElement(By.xpath("//*[@id='custom-tabs-two-tabContent']/div/div[1]/div[2]/div/div/table/thead/tr/th[2]/button/img[2]"));
elementInsideTable.click();
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

//driver.findElement(By.xpath("//*[@id='custom-tabs-two-tabContent']/div/div[1]/div[2]/div/div/table/thead/tr/th[2]/button/img[2]")).click();
//Thread.sleep(1000);

System.out.println("Before opening pop up");
String mainWindowHandle = driver.getWindowHandle();

// Perform an action to open the form popup
// Switch to the popup window

 java.util.Set<String> windowHandles = driver.getWindowHandles();
  for (String handle : windowHandles) {
   if (!handle.equals(mainWindowHandle)) {
     driver.switchTo().window(handle);
    }
} 
	   
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//click on Choose button inside pop up

WebElement choosefile = driver.findElement(By.xpath((("/html/body/app-root/app-layouts/div/div/div/app-my-tasks/div[6]/div/div/form/div/div[1]/div[2]/div"))));
choosefile.click();

Thread.sleep(2000);

StringSelection filename = new StringSelection("Leave Policyv1-9-6-44");
// StringSelection filePath = new StringSelection("Leave Policyv1-9-6-44");
Toolkit.getDefaultToolkit().getSystemClipboard().setContents(filename,null);

Robot robot = new Robot();

// Simulate keypresses to navigate and select the file in the dialog

robot.keyPress(KeyEvent.VK_CONTROL);
robot.keyPress(KeyEvent.VK_V);
robot.keyRelease(KeyEvent.VK_V);
robot.keyRelease(KeyEvent.VK_CONTROL);

robot.keyPress(KeyEvent.VK_ENTER);
robot.keyRelease(KeyEvent.VK_ENTER);
Thread.sleep(2000);
driver.findElement(By.xpath("//*[@id='addAtta']/div/div/form/div/div[2]/button[1]")).click();
Thread.sleep(2000);  
//driver.findElement(By.xpath("/html/body/app-root/app-layouts/div/div/div/app-topbar/div[1]/img")).click();
//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
} 
}