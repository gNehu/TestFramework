package Utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadPropertiesFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		FileInputStream fr = new FileInputStream("src/test/resources/Configfiles/config.properties");
		Properties p = new Properties();
		p.load(fr);
	    p.getProperty("browser.type");
	    p.getProperty("testurl");
	}
	}